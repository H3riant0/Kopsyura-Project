/*
SQLyog Enterprise - MySQL GUI v8.2 RC2
MySQL - 5.5.5-10.4.19-MariaDB : Database - kopw1798_kopsyura
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`kopw1798_kopsyura` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `kopw1798_kopsyura`;

/*Table structure for table `tb_member` */

DROP TABLE IF EXISTS `tb_member`;

CREATE TABLE `tb_member` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `id_anggota` int(15) NOT NULL,
  `nama_lengkap` varchar(35) DEFAULT NULL,
  `gender` varchar(15) NOT NULL,
  `tempat_lahir` varchar(25) NOT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `ktp` varchar(21) DEFAULT NULL,
  `jalan` varchar(150) DEFAULT NULL,
  `kel` varchar(33) NOT NULL,
  `kec` varchar(25) DEFAULT NULL,
  `kab` varchar(25) DEFAULT NULL,
  `prov` varchar(25) DEFAULT NULL,
  `kodepos` varchar(10) NOT NULL,
  `alamat_lengkap` varchar(50) DEFAULT NULL,
  `hp` varchar(17) DEFAULT NULL,
  `produk` varchar(150) DEFAULT NULL,
  `usaha` varchar(150) DEFAULT NULL,
  `user` varchar(25) DEFAULT NULL,
  `pass` varchar(25) DEFAULT NULL,
  `email` varchar(25) NOT NULL,
  `level` varchar(15) DEFAULT NULL,
  `status` varchar(15) DEFAULT NULL,
  `status_on` varchar(5) NOT NULL DEFAULT '1',
  `foto` varchar(111) NOT NULL DEFAULT '',
  `datetime` datetime DEFAULT current_timestamp(),
  `kwitansi` varchar(100) NOT NULL,
  `twibon` varchar(200) NOT NULL,
  `ramadhan` varchar(250) NOT NULL,
  `tanggal_transfer` date NOT NULL,
  `user_input` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3933 DEFAULT CHARSET=latin1;

/*Data for the table `tb_member` */

insert into `tb_member` (`id`, `id_anggota`, `nama_lengkap`, `gender`, `tempat_lahir`, `tanggal_lahir`, `ktp`, `jalan`, `kel`, `kec`, `kab`, `prov`, `kodepos`, `alamat_lengkap`, `hp`, `produk`, `usaha`, `user`, `pass`, `email`, `level`, `status`, `status_on`, `foto`, `datetime`, `kwitansi`, `twibon`, `ramadhan`, `tanggal_transfer`, `user_input`) values('114','313000114','Abdul Shobur','','Bandung','0000-00-00',NULL,NULL,'','Teluk Jambe timur','Karawang','Jawa Barat','','Teluk Jambe timur,Karawang,Jawa Barat','085218177050','Warnas bunda l','MAKANAN','Abdul Shobur','085218177050','1','Anggota','Aktif','1','','2021-01-01 00:00:01','','','','0000-00-00',NULL);
insert into `tb_member` (`id`, `id_anggota`, `nama_lengkap`, `gender`, `tempat_lahir`, `tanggal_lahir`, `ktp`, `jalan`, `kel`, `kec`, `kab`, `prov`, `kodepos`, `alamat_lengkap`, `hp`, `produk`, `usaha`, `user`, `pass`, `email`, `level`, `status`, `status_on`, `foto`, `datetime`, `kwitansi`, `twibon`, `ramadhan`, `tanggal_transfer`, `user_input`) values('3933','0','Admin','','',NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'Admin','12345','','Admin',NULL,'1','','2021-07-09 10:05:38','','','','0000-00-00',NULL);
insert into `tb_member` (`id`, `id_anggota`, `nama_lengkap`, `gender`, `tempat_lahir`, `tanggal_lahir`, `ktp`, `jalan`, `kel`, `kec`, `kab`, `prov`, `kodepos`, `alamat_lengkap`, `hp`, `produk`, `usaha`, `user`, `pass`, `email`, `level`, `status`, `status_on`, `foto`, `datetime`, `kwitansi`, `twibon`, `ramadhan`, `tanggal_transfer`, `user_input`) values('3935','0',NULL,'','',NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'jayto','123','',NULL,NULL,'1','','2021-07-09 23:17:38','','','','0000-00-00',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
