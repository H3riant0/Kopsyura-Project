<?php   
require_once 'koneksi.php';

$respone    = array();

if ($konek){
    $id             = $_POST['id'];
    $nama_lengkap   = $_POST['nama_lengkap'];
    $gender         = $_POST['gender'];
    $tempat_lahir   = $_POST['tempat_lahir'];
    $tanggal_lahir  = $_POST['tanggal_lahir'];
	$alamat_lengkap = $_POST['alamat_lengkap'];
    $hp             = $_POST['hp'];
    $produk         = $_POST['produk'];
    $usaha          = $_POST['usaha'];
    $status         = $_POST['status'];
    

    $update      = "UPDATE tb_member SET 
                    nama_lengkap = '$nama_lengkap',
                    gender 	= '$gender',
                    tempat_lahir 	= '$tempat_lahir',
                    tanggal_lahir 	= '$tanggal_lahir',
                    alamat_lengkap 	= '$alamat_lengkap',
                    hp 	            = '$hp',
                    produk 	        = '$produk',
                    usaha 	        = '$usaha',
                    status 	        = '$status'
                    WHERE id = '$id'";
    
    
    if ($id != ''){
        $result     = mysqli_query($konek, $update);
        if ($result){
            array_push($respone, array(
                'status' => 'Update Data Berhasil'
            ));
        } else{
            array_push($respone, array(
                'status' => 'Update Data Berhasil Gagal'
            ));
        }
    }
    else{
        array_push($respone, array(
            'status' => 'Update Data Berhasil Gagal'
        ));
    }
}
else
{
    array_push($respone, array(
		'status' => 'Failed'
	));
}
echo json_encode(array("array_response" => $respone));

mysqli_close($konek);
?>