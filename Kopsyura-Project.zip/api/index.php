<?php
require("koneksi.php");
$perintah = "SELECT * FROM tb_member";
$eksekusi = mysqli_query($konek,$perintah);
$cek      = mysqli_affected_rows($konek);

$response['kode'] = 0;
$response['pesan'] = "Data Tidak Tersedia"; 
$response['data'] = array();

if($cek > 0){

	$response['kode'] = 1;
	$response['pesan'] = "Data Anggota Aktif";
	
    while($ambil = mysqli_fetch_object($eksekusi)){
        $F["id"]            = $ambil->id;
        $F["id_anggota"]    = $ambil->id_anggota;
        $F["nama_lengkap"]  = $ambil->nama_lengkap;
        $F["gender"]        = $ambil->gender;
        $F["tempat_lahir"]  = $ambil->tempat_lahir;
        $F["tanggal_lahir"] = $ambil->tanggal_lahir;
        $F["alamat"]        = $ambil->alamat_lengkap;
        $F["hp"]            = $ambil->hp;
        $F["produk"]        = $ambil->produk;
        $F["usaha"]         = $ambil->usaha;
        $F["status"]        = $ambil->status;
		$F["username"] = $ambil->user;
        array_push($response["data"], $F);
    }
}

echo json_encode($response);
mysqli_close($konek);
?>