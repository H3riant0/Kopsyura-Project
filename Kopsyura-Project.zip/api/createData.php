<?php   
require_once 'koneksi.php';

$respone    = array();
if ($konek){
    $username = $_POST['username'];
    $password = $_POST['password'];
    //$email = $_POST['email'];

    $insert      = "INSERT INTO tb_member (user,pass) VALUES('$username','$password')";
	$cek      = "SELECT * FROM tb_member WHERE user = '$username' and pass = '$password'";
    
    
    if ($username != '' && $password != ''){
		$result = $konek->query($cek);
        //$result = mysqli_query($konek, $cek);
        
		if ($result->num_rows > 0){
            array_push($respone, array(
					'status' => 'Failed'
				));
        } else{
            
			$rowInsert = mysqli_query($konek, $insert);
        
			if ($rowInsert){
				array_push($respone, array(
					'status' => 'OK'
				));
			} else{
				array_push($respone, array(
					'status' => 'Failed'
				));
			}
		
        }
		
    }
    else{
        array_push($respone, array(
            'status' => 'Failed'
        ));
    }
}
else
{
    array_push($respone, array(
        'status' => 'Failed'
    ));
}
echo json_encode(array("array_response" => $respone));

mysqli_close($konek);
?>