<?php   
require_once 'koneksi.php';

$respone    = array();

if ($konek){
    $username = $_POST['username'];
    $password = $_POST['password'];

    $cek      = "SELECT * FROM tb_member WHERE user = '$username' and pass = '$password'";
    
    if ($username != null && $password != null) {
		$result = $konek->query($cek);
        //$result = mysqli_query($konek, $cek);
        
		if ($result->num_rows > 0){
            array_push($respone, array(
                'status' => 'Login Berhasil!'
            ));
        } else{
            array_push($respone, array(
                'status' => 'Login Gagal!'
            ));
        }
    }
    else{
        array_push($respone, array(
            'status' => 'Login Gagal!'
        ));
    }
}
else
{
    array_push($respone, array(
        'status' => 'Login Gagal!'
    ));
}
echo json_encode(array("array_response" => $respone));
mysqli_close($konek);
?>