<?php   
require_once 'koneksi.php';

if ($konek){
    $id = $_POST['id'];
    

    $hapus      = "DELETE FROM tb_member WHERE id = '$id'";
    
    
    if ($id != ''){
        $result     = mysqli_query($konek, $hapus);
        $respone    = array();
        if ($result){
            array_push($respone, array(
                'status' => 'HAPUS DATA SUKSES'
            ));
        } else{
            array_push($respone, array(
                'status' => 'HAPUS DATA GAGAL'
            ));
        }
    }
    else{
        array_push($respone, array(
            'status' => 'HAPUS DATA GAGAL'
        ));
    }
}
else
{
    array_push($respone, array(
        'status' => 'HAPUS DATA GAGAL'
    ));
}
echo json_encode(array("array_response" => $respone));
mysqli_close($konek);
?>