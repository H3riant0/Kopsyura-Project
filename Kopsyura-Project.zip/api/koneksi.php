<?php
$host   = "localhost";  
$user   = "root";
$pass   = "";
$db     = "kopw1798_kopsyura";

$konek  = mysqli_connect($host,$user,$pass,$db) or die("Database Tidak Terhubung");
?>