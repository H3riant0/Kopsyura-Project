package com.jayto.kopsyura.view.list;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.jayto.kopsyura.R;
import com.jayto.kopsyura.data.model.list.Member;
import com.jayto.kopsyura.view.update.UpdateActivity;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity
        implements ListView, ListAdapter.OnAdapterListener {

    public static Intent movePage(Context context) {
        return new Intent(context, ListActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
    }

    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private ProgressDialog progressDialog;

    private ListPresenter listPresenter;
    private List<Member> members;
    private ListAdapter listAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        setPresenter();
        setView();
    }

    private void setPresenter() {
        listPresenter = new ListPresenter(this);
    }

    private void setView() {
        recyclerView = findViewById(R.id.rv_member);
        progressBar = findViewById(R.id.progress_bar);
        progressDialog = new ProgressDialog(this);

        members = new ArrayList<>();
        listAdapter = new ListAdapter(members);
        listAdapter.setListener(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(listAdapter);
        new ItemTouchHelper(simpleCallback).attachToRecyclerView(recyclerView);
    }

    private void readData() {
        listPresenter.readData();
    }

    ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            progressDialog.setMessage("loading");
            progressDialog.show();
            Member member = members.get(viewHolder.getBindingAdapterPosition());
            listPresenter.deleteData(String.valueOf(member.id), viewHolder.getBindingAdapterPosition());
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        new Handler().postDelayed(this::readData, 50);
    }

    @Override
    public void onSuccessReadData(List<Member> members) {
        if (progressBar.getVisibility() == View.VISIBLE) {
            progressBar.setVisibility(View.GONE);
        }
        if (recyclerView.getVisibility() == View.GONE) {
            recyclerView.setVisibility(View.VISIBLE);
        }

        if (this.members == null) new ArrayList<>();
        this.members.clear();

        if (members.isEmpty()) {
            this.members.add(new Member(-1));
        } else {
            this.members.addAll(members);
        }

        listAdapter.notifyDataSetChanged();
    }

    @Override
    public void onErrorReadData(String errMsg) {
        if (progressBar.getVisibility() == View.VISIBLE) {
            progressBar.setVisibility(View.GONE);
        }

        Toast.makeText(this, errMsg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onSuccessDeleted(int position) {
        progressDialog.dismiss();
        members.remove(position);
        listAdapter.notifyDataSetChanged();
        Toast.makeText(this, "Delete Success", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onErrorDeleted(String errMsg) {
        progressDialog.dismiss();
        Toast.makeText(this, errMsg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void clickItemListener(Member member) {
        if (member != null) {
            startActivity(UpdateActivity.generateIntent(ListActivity.this, member));
        }
    }
}
