package com.jayto.kopsyura.data.network.request;

import com.jayto.kopsyura.data.model.list.ListResponse;
import com.jayto.kopsyura.data.model.auth.Auth;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiRequest {

    @FormUrlEncoded
    @POST("loginData.php")
    Call<Auth> login(
            @Field("username") String username,
            @Field("password") String password
    );

    @GET("index.php")
    Call<ListResponse> readData();

    @FormUrlEncoded
    @POST("createData.php")
    Call<Auth> register(@Field("username") String username,
                        @Field("password") String password);

    @FormUrlEncoded
    @POST("updateData.php")
    Call<Auth> update(@Field("id") String id,
                        @Field("nama_lengkap") String nama_lengkap,
                        @Field("gender") String gender,
                        @Field("tempat_lahir") String tempat_lahir,
                        @Field("tanggal_lahir") String tanggal_lahir,
                        @Field("alamat_lengkap") String alamat_lengkap,
                        @Field("hp") String hp,
                        @Field("produk") String produk,
                        @Field("usaha") String usaha,
                        @Field("status") String status);

    @FormUrlEncoded
    @POST("deleteData.php")
    Call<Auth> delete(@Field("id") String id);
}