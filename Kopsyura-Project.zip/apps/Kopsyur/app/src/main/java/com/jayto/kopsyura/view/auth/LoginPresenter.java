package com.jayto.kopsyura.view.auth;

import com.jayto.kopsyura.data.model.auth.Auth;
import com.jayto.kopsyura.data.network.client.NetworkClient;
import com.jayto.kopsyura.data.network.request.ApiRequest;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginPresenter {
    private final LoginView view;

    public LoginPresenter(LoginView view) {
        this.view = view;
    }

    public void verifyAuth(String username, String password) {
        List<String> stringList = new ArrayList<>();
        if (username == null || username.equals("")) {
            stringList.add("username tidak boleh kosong");
        }

        if (password == null || password.equals("")) {
            stringList.add("username tidak boleh kosong");
        }

        if (stringList.isEmpty()) {
            view.onSuccessVerifyAuth(username, password);
        } else {
            view.onErrorVerifyAuth(stringList);
        }
    }

    public void hitLogin(String username, String password) {
        NetworkClient.getClient()
                .create(ApiRequest.class)
                .login(username, password)
                .enqueue(new Callback<Auth>() {
                    @Override
                    public void onResponse(Call<Auth> call, Response<Auth> response) {
                        if (response.isSuccessful()) {
                            Auth auth = response.body();
                            if (auth != null) {
                                if (auth.authRespons.get(0).status.equals("Login Berhasil!")) {
                                    view.onSuccessLogin();
                                } else {
                                    view.onErrorLogin(auth.authRespons.get(0).status);
                                }
                            }
                        } else {
                            view.onErrorLogin(response.message());
                        }
                    }

                    @Override
                    public void onFailure(Call<Auth> call, Throwable t) {
                        view.onErrorLogin(t.getMessage());
                    }
                });
    }
}
