package com.jayto.kopsyura.data.model.auth;

public class AuthResponse {
    public String status;
}
