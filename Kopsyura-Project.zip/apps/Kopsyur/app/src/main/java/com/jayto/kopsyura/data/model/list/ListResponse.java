package com.jayto.kopsyura.data.model.list;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ListResponse {
    public int kode;
    public String pesan;
    @SerializedName("data")
    public List<Member> members;
}
