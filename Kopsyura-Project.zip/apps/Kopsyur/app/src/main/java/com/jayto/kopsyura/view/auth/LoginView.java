package com.jayto.kopsyura.view.auth;

import java.util.List;

public interface LoginView {
    void onSuccessLogin();
    void onErrorLogin(String errMsg);

    void onSuccessVerifyAuth(String username, String password);
    void onErrorVerifyAuth(List<String> errMsg);
}
