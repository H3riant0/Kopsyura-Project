package com.jayto.kopsyura.view.register;

public interface RegisterView {
    void onSuccessRegister();
    void onErrorRegister(String errMsg);
}
