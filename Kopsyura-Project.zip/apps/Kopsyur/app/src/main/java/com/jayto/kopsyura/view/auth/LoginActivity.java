package com.jayto.kopsyura.view.auth;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.jayto.kopsyura.R;
import com.jayto.kopsyura.view.list.ListActivity;
import com.jayto.kopsyura.view.register.RegisterActivity;

import java.util.List;

public class LoginActivity extends AppCompatActivity implements LoginView {

    private EditText etUsername;
    private EditText etPassword;
    private Button btnLogin;
    private Button btnRegister;

    private LoginPresenter loginPresenter;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        setPresenter();
        setView();
        setListener();
    }

    private void setPresenter() {
        loginPresenter = new LoginPresenter(this);
    }

    private void setListener() {
        btnLogin.setOnClickListener(v -> {
            //TODO EDIT
//            String username = etUsername.getText().toString();
//            String pass = etPassword.getText().toString();
            loginPresenter.verifyAuth("Abdul Baroroh", "083866794942");
        });
        btnRegister.setOnClickListener(v -> startActivity(RegisterActivity.generateIntent(LoginActivity.this)));
    }

    private void setView() {
        progressDialog = new ProgressDialog(this);

        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_login);
        btnRegister = findViewById(R.id.btn_register);
    }

    @Override
    public void onSuccessLogin() {
        progressDialog.dismiss();
        Toast.makeText(this, "berhasil login", Toast.LENGTH_SHORT).show();
        startActivity(ListActivity.movePage(LoginActivity.this));
    }

    @Override
    public void onErrorLogin(String errMsg) {
        progressDialog.dismiss();
        Toast.makeText(this, errMsg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onSuccessVerifyAuth(String username, String password) {
        progressDialog.setMessage("loading");
        progressDialog.show();
        loginPresenter.hitLogin(username, password);
    }

    @Override
    public void onErrorVerifyAuth(List<String> errMsg) {
        if (!errMsg.isEmpty()) {
            for (String err : errMsg) {
                Toast.makeText(this, err, Toast.LENGTH_SHORT).show();
            }
        }
    }

}
