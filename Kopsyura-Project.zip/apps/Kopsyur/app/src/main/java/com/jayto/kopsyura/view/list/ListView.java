package com.jayto.kopsyura.view.list;

import com.jayto.kopsyura.data.model.list.Member;

import java.util.List;

public interface ListView {
    void onSuccessReadData(List<Member> members);
    void onErrorReadData(String errMsg);

    void onSuccessDeleted(int position);
    void onErrorDeleted(String errMsg);
}
