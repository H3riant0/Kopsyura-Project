package com.jayto.kopsyura.view.list;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.jayto.kopsyura.R;
import com.jayto.kopsyura.data.model.list.Member;

import java.util.List;

public class ListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<Member> members;
    private OnAdapterListener listener;

    public ListAdapter(List<Member> members) {
        this.members = members;
    }

    public void setListener(OnAdapterListener listener) {
        this.listener = listener;
    }

    public interface OnAdapterListener{
        void clickItemListener(Member member);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View layout;
        if (viewType == -1) {
            layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list_empty, parent, false);
            return new EmptyHolder(layout);
        } else {
            layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list, parent, false);
            return new MemberHolder(layout);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (getItemViewType(position) != -1) {
            Member data = members.get(position);
            MemberHolder memberHolder = (MemberHolder) holder;
            memberHolder.tvActive.setText(data.status);
            memberHolder.tvName.setText(data.nama_lengkap);
            memberHolder.tvIdMember.setText(data.id_anggota);
            if (data.tanggal_lahir != null) {
                memberHolder.tvDate.setText(data.tanggal_lahir);
            }
            memberHolder.tvGender.setText(data.gender);

            if (data.tempat_lahir != null && !data.tempat_lahir.equals("")) {
                memberHolder.tvPlace.setText("Tempat Lahir : " + data.tempat_lahir);
            }
            if (!data.alamat.equals("")) {
                memberHolder.tvAddress.setText("Alamat : " +data.alamat);
            }
            if (data.usaha != null && !data.usaha.equals("")) {
                memberHolder.tvBusiness.setText("Usaha : " +data.usaha);
            }
            if (data.produk != null && !data.produk.equals("")) {
                memberHolder.tvProduct.setText("Produk : " +data.produk);
            }
            memberHolder.tvPhone.setText(data.hp);
        }
    }

    @Override
    public int getItemCount() {
        return members.size();
    }

    @Override
    public int getItemViewType(int position) {
        return members.get(position).id;
    }

    public class MemberHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvName, tvIdMember, tvDate, tvGender, tvActive, tvAddress,
                tvBusiness, tvPhone, tvProduct, tvPlace;
        LinearLayout ctView;

        public MemberHolder(@NonNull View view) {
            super(view);

            tvName = view.findViewById(R.id.tv_name);
            tvIdMember = view.findViewById(R.id.tv_id_member);
            tvDate = view.findViewById(R.id.tv_birthdate);
            tvGender = view.findViewById(R.id.tv_gender);
            tvAddress = view.findViewById(R.id.tv_address);
            tvBusiness = view.findViewById(R.id.tv_business);
            tvPhone = view.findViewById(R.id.tv_phone);
            tvProduct = view.findViewById(R.id.tv_product);
            tvActive = view.findViewById(R.id.tv_active);
            tvPlace = view.findViewById(R.id.tv_place);
            ctView = view.findViewById(R.id.ct_view);

            ctView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            if (listener != null) {
                listener.clickItemListener(members.get(getBindingAdapterPosition()));
            }
        }
    }

    public class EmptyHolder extends RecyclerView.ViewHolder {
        public EmptyHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
