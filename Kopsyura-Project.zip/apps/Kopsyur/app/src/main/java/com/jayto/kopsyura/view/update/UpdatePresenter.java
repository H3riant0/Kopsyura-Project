package com.jayto.kopsyura.view.update;

import com.jayto.kopsyura.data.model.auth.Auth;
import com.jayto.kopsyura.data.model.list.Member;
import com.jayto.kopsyura.data.network.client.NetworkClient;
import com.jayto.kopsyura.data.network.request.ApiRequest;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdatePresenter {

    UpdateView view;

    public UpdatePresenter(UpdateView view) {
        this.view = view;
    }

    public void update(Member member) {
        NetworkClient.getClient()
                .create(ApiRequest.class)
                .update(
                        String.valueOf(member.id), member.nama_lengkap, member.gender, member.tempat_lahir,
                        member.tanggal_lahir, member.alamat, member.hp, member.produk, member.usaha, member.status
                )
                .enqueue(new Callback<Auth>() {
                    @Override
                    public void onResponse(Call<Auth> call, Response<Auth> response) {
                        if (response.isSuccessful()) {
                            Auth auth = response.body();
                            if (auth != null) {
                                if (auth.authRespons.get(0).status.equals("Update Data Berhasil")) {
                                    view.onSuccessUpdate();
                                } else {
                                    view.onErrorUpdate(auth.authRespons.get(0).status);
                                }
                            }
                        } else {
                            view.onErrorUpdate(response.message());
                        }
                    }

                    @Override
                    public void onFailure(Call<Auth> call, Throwable t) {
                        view.onErrorUpdate(t.getMessage());
                    }
                });
    }
}
