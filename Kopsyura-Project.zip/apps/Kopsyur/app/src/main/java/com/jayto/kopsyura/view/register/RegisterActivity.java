package com.jayto.kopsyura.view.register;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.jayto.kopsyura.R;
import com.jayto.kopsyura.view.auth.LoginPresenter;
import com.jayto.kopsyura.view.auth.LoginView;

import java.util.List;

public class RegisterActivity extends AppCompatActivity implements LoginView, RegisterView {

    public static Intent generateIntent(Context context) {
        return new Intent(context, RegisterActivity.class);
    }

    private EditText etUsername;
    private EditText etPassword;
    private Button btnRegister;

    private LoginPresenter loginPresenter;
    private RegisterPresenter registerPresenter;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        setPresenter();
        setView();
        setListener();
    }

    private void setPresenter() {
        loginPresenter = new LoginPresenter(this);
        registerPresenter = new RegisterPresenter(this);
    }

    private void setListener() {
        btnRegister.setOnClickListener(v -> {
            String username = etUsername.getText().toString();
            String pass = etPassword.getText().toString();
            loginPresenter.verifyAuth(username, pass);
        });
    }

    private void setView() {
        progressDialog = new ProgressDialog(this);

        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        btnRegister = findViewById(R.id.btn_register);
    }

    @Override
    public void onSuccessLogin() {

    }

    @Override
    public void onErrorLogin(String errMsg) {

    }

    @Override
    public void onSuccessVerifyAuth(String username, String password) {
        progressDialog.setMessage("loading");
        progressDialog.show();
        registerPresenter.register(username, password);
    }

    @Override
    public void onErrorVerifyAuth(List<String> errMsg) {
        if (!errMsg.isEmpty()) {
            for (String err : errMsg) {
                Toast.makeText(this, err, Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onSuccessRegister() {
        progressDialog.dismiss();
        Toast.makeText(this, "Yeay, Register Success", Toast.LENGTH_SHORT).show();
        onBackPressed();
    }

    @Override
    public void onErrorRegister(String errMsg) {
        progressDialog.dismiss();
    }
}
