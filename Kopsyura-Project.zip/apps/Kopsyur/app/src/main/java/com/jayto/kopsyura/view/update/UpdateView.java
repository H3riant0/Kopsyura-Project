package com.jayto.kopsyura.view.update;

public interface UpdateView {
//    void onSuccessVerifyUpdate(Member member);
//    void onErrorVerifyUpdate(List<String> errMsg);

    void onSuccessUpdate();
    void onErrorUpdate(String errMsg);
}
