package com.jayto.kopsyura.data.model.list;

import java.io.Serializable;

public class Member implements Serializable {
    public int id;
    public String id_anggota;
    public String nama_lengkap;
    public String gender;
    public String tempat_lahir;
    public String tanggal_lahir;
    public String alamat;
    public String hp;
    public String produk;
    public String usaha;
    public String status;

    public Member(int id) {
        this.id = id;
    }

    public Member(int id, String id_anggota, String nama_lengkap, String gender, String tempat_lahir, String tanggal_lahir, String alamat, String hp, String produk, String usaha, String status) {
        this.id = id;
        this.id_anggota = id_anggota;
        this.nama_lengkap = nama_lengkap;
        this.gender = gender;
        this.tempat_lahir = tempat_lahir;
        this.tanggal_lahir = tanggal_lahir;
        this.alamat = alamat;
        this.hp = hp;
        this.produk = produk;
        this.usaha = usaha;
        this.status = status;
    }
}
