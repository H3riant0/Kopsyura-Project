package com.jayto.kopsyura.data.model.auth;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Auth {
    @SerializedName("array_response")
    public List<AuthResponse> authRespons;
}
