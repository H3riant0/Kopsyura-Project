package com.jayto.kopsyura.view.register;

import com.jayto.kopsyura.data.model.auth.Auth;
import com.jayto.kopsyura.data.network.client.NetworkClient;
import com.jayto.kopsyura.data.network.request.ApiRequest;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterPresenter {
    RegisterView view;

    public RegisterPresenter(RegisterView view) {
        this.view = view;
    }

    public void register(String username, String password) {
        NetworkClient.getClient()
                .create(ApiRequest.class)
                .register(username, password)
                .enqueue(new Callback<Auth>() {
                    @Override
                    public void onResponse(Call<Auth> call, Response<Auth> response) {
                        if (response.isSuccessful()) {
                            Auth auth = response.body();
                            if (auth != null) {
                                if (auth.authRespons.get(0).status.equals("OK")) {
                                    view.onSuccessRegister();
                                } else {
                                    view.onErrorRegister(auth.authRespons.get(0).status);
                                }
                            }
                        } else {
                            view.onErrorRegister(response.message());
                        }
                    }

                    @Override
                    public void onFailure(Call<Auth> call, Throwable t) {
                        view.onErrorRegister(t.getMessage());
                    }
                });
    }
}
