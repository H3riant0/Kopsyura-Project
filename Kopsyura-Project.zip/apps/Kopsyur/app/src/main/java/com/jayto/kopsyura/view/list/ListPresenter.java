package com.jayto.kopsyura.view.list;

import com.jayto.kopsyura.data.model.auth.Auth;
import com.jayto.kopsyura.data.model.list.ListResponse;
import com.jayto.kopsyura.data.model.list.Member;
import com.jayto.kopsyura.data.network.client.NetworkClient;
import com.jayto.kopsyura.data.network.request.ApiRequest;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListPresenter {

    ListView view;

    public ListPresenter(ListView view) {
        this.view = view;
    }

    public void readData() {
        NetworkClient.getClient()
                .create(ApiRequest.class)
                .readData()
                .enqueue(new Callback<ListResponse>() {
                    @Override
                    public void onResponse(Call<ListResponse> call, Response<ListResponse> response) {
                        if (response.isSuccessful()) {
                            ListResponse listResponse = response.body();
                            if (listResponse != null) {
                                if (listResponse.kode != 0) {
                                    view.onSuccessReadData(listResponse.members);
                                } else {
                                    view.onErrorReadData(listResponse.pesan);
                                }
                            }

                        } else {
                            view.onErrorReadData(response.message());
                        }
                    }

                    @Override
                    public void onFailure(Call<ListResponse> call, Throwable t) {
                        view.onErrorReadData(t.getMessage());
                    }
                });
    }

    public void deleteData(String id, int position) {
        NetworkClient.getClient()
                .create(ApiRequest.class)
                .delete(id)
                .enqueue(new Callback<Auth>() {
                    @Override
                    public void onResponse(Call<Auth> call, Response<Auth> response) {
                        if (response.isSuccessful()) {
                            Auth auth = response.body();
                            if (auth != null) {
                                if (auth.authRespons.get(0).status.equals("HAPUS DATA SUKSES")) {
                                    view.onSuccessDeleted(position);
                                } else {
                                    view.onErrorDeleted(auth.authRespons.get(0).status);
                                }
                            }
                        } else {
                            view.onErrorDeleted(response.message());
                        }
                    }

                    @Override
                    public void onFailure(Call<Auth> call, Throwable t) {

                    }
                });
    }
}
