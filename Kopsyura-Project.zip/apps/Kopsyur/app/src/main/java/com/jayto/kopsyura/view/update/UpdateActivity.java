package com.jayto.kopsyura.view.update;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.jayto.kopsyura.R;
import com.jayto.kopsyura.data.model.list.Member;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class UpdateActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener, UpdateView {

    public static Intent generateIntent(Context context, Member member) {
        return new Intent(context, UpdateActivity.class)
                .putExtra("member", member);
    }

    private Member member;
    private EditText etFullName, etPlace, etPhone,
            etDate, etAddress, etBusiness, etProduct;
    private RadioGroup rgGender, rgStatus;
    private RadioButton rbGirl, rbMen;
    private RadioButton rbActive, rvNonActive;
    private Button btnUpdate;
    private ProgressDialog progressDialog;
    private ImageButton btnBack;
    private View header;

    private String genderSelect = "", statusSelect = "";
    private UpdatePresenter updatePresenter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        if (getIntent().getExtras() != null
                && getIntent().getSerializableExtra("member") != null) {
            member = (Member) getIntent().getSerializableExtra("member");
        }

        setPresenter();
        setView();
        setListener();
    }

    private void setPresenter() {
        updatePresenter = new UpdatePresenter(this);
    }

    private void setListener() {
        rgGender.setOnCheckedChangeListener(this);
        rgStatus.setOnCheckedChangeListener(this);
        btnBack.setOnClickListener(v -> onBackPressed());
        etDate.setOnClickListener((View.OnClickListener) v -> {
            Calendar calendar = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(UpdateActivity.this, (DatePickerDialog.OnDateSetListener) (view, year, month, dayOfMonth) -> {
                Calendar date = Calendar.getInstance();
                date.set(year, month, dayOfMonth);
                SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy", new Locale("id"));
                etDate.setText(sdf.format(date.getTime()));
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
            datePickerDialog.show();
        });
        btnUpdate.setOnClickListener(v -> {
            String fullName = etFullName.getText().toString();
            String place = etPlace.getText().toString();
            String phone = etPhone.getText().toString();
            String date = etDate.getText().toString();
            String address = etAddress.getText().toString();
            String business = etBusiness.getText().toString();
            String product = etProduct.getText().toString();

            progressDialog.setMessage("loading");
            progressDialog.show();

            Member member = new Member(
                    UpdateActivity.this.member.id, UpdateActivity.this.member.id_anggota,
                    fullName, genderSelect, place, date, address, phone,
                    product, business, statusSelect
            );
            updatePresenter.update(member);
        });
    }

    private void setView() {
        progressDialog = new ProgressDialog(this);

        header = findViewById(R.id.layout_header);
        btnBack = header.findViewById(R.id.btn_back);
        etFullName = findViewById(R.id.et_full_name);
        etPlace = findViewById(R.id.et_place);
        etPhone = findViewById(R.id.et_phone);
        etDate = findViewById(R.id.et_birth_date);
        etAddress = findViewById(R.id.et_address);
        etBusiness = findViewById(R.id.et_business);
        etProduct = findViewById(R.id.et_product);
        rgGender = findViewById(R.id.rg_gender);
        rgStatus = findViewById(R.id.rg_status);
        rbGirl = findViewById(R.id.rb_girl);
        rbMen = findViewById(R.id.rb_men);
        rbActive = findViewById(R.id.rb_active);
        rvNonActive = findViewById(R.id.rb_non_active);
        btnUpdate = findViewById(R.id.btn_update);

        setDataView();
    }

    private void setDataView() {
        statusSelect = member.status;
        genderSelect = member.gender;
        if (member.status.equals("Aktif")) {
            rgStatus.check(rbActive.getId());
        } else {
            rgStatus.check(rvNonActive.getId());
        }

        etFullName.setText(member.nama_lengkap);
        if (member.tanggal_lahir != null) {
            etDate.setText(member.tanggal_lahir);
        }

        if (member.tempat_lahir != null && !member.tempat_lahir.equals("")) {
            etPlace.setText(member.tempat_lahir);
        }

        if (member.gender.equals("Perempuan")) {
            rgGender.check(rbGirl.getId());
        } else {
            rgGender.check(rbMen.getId());
        }

        if (!member.alamat.equals("")) {
            etAddress.setText(member.alamat);
        }
        if (member.usaha != null && !member.usaha.equals("")) {
            etBusiness.setText(member.usaha);
        }
        if (member.produk != null && !member.produk.equals("")) {
            etProduct.setText(member.produk);
        }
        etPhone.setText(member.hp);
    }


    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        RadioButton radioButton = findViewById(checkedId);
        if (radioButton == rbActive) {
            this.statusSelect = "Aktif";
        } else if (radioButton == rvNonActive) {
            this.statusSelect = "Tidak Aktif";
        } else if (radioButton == rbGirl) {
            this.genderSelect = "Perempuan";
        } else {
            this.genderSelect = "Laki-laki";
        }
    }

    @Override
    public void onSuccessUpdate() {
        progressDialog.dismiss();
        Toast.makeText(this, "Yeay, Edit Success", Toast.LENGTH_SHORT).show();
        onBackPressed();
    }

    @Override
    public void onErrorUpdate(String errMsg) {
        progressDialog.dismiss();
        Toast.makeText(this, errMsg, Toast.LENGTH_SHORT).show();
    }
}
